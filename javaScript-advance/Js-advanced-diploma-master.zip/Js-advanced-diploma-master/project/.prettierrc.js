module.exports = {
  singleQuote: true,
}
