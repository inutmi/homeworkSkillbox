import './main.sass';
import './assets/icons/pencil.svg';
import './js/notifications';
import './js/routing';
